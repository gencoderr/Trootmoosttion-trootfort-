import React, { useState, useCallback } from 'react';
import { correctText, translateText, getLotteryResult, teleportToWebsite, generateHyperlink, obfuscateText, generateTransmissionKey, generateTransmissionLore } from './services/geminiService';
import Icon from './components/Icon';
import Spinner from './components/Spinner';

type Style = 'Formal' | 'Casual' | 'Code Comments' | 'Pirate';

const STYLES: { name: Style; icon: React.ComponentProps<typeof Icon>['name'] }[] = [
    { name: 'Formal', icon: 'briefcase' },
    { name: 'Casual', icon: 'smiley' },
    { name: 'Code Comments', icon: 'code' },
    { name: 'Pirate', icon: 'pirate' },
];

type WebsiteTab = 'preview' | 'code';

const App: React.FC = () => {
  const [originalText, setOriginalText] = useState<string>('');
  const [correctedText, setCorrectedText] = useState<string>('');
  const [translatedText, setTranslatedText] = useState<string>('');
  const [lotteryText, setLotteryText] = useState<string>('');
  const [websiteHtml, setWebsiteHtml] = useState<string>('');
  const [generatedLink, setGeneratedLink] = useState<string>('');
  const [obfuscatedText, setObfuscatedText] = useState<string>('');
  const [creditApiKey, setCreditApiKey] = useState<string>('');
  const [obfuscatedLink, setObfuscatedLink] = useState<string>('');
  const [manualKeyInput, setManualKeyInput] = useState<string>('');
  const [transmissionLore, setTransmissionLore] = useState<string>('');
  
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isTranslating, setIsTranslating] = useState<boolean>(false);
  const [isLotteryLoading, setIsLotteryLoading] = useState<boolean>(false);
  const [isWebsiteLoading, setIsWebsiteLoading] = useState<boolean>(false);
  const [isLinkLoading, setIsLinkLoading] = useState<boolean>(false);
  const [isObfuscating, setIsObfuscating] = useState<boolean>(false);
  const [isFetchingKey, setIsFetchingKey] = useState<boolean>(false);
  const [isObfuscatedLinkLoading, setIsObfuscatedLinkLoading] = useState<boolean>(false);
  const [isCompletingTransmission, setIsCompletingTransmission] = useState<boolean>(false);
  const [isLoreLoading, setIsLoreLoading] = useState<boolean>(false);

  const [error, setError] = useState<string | null>(null);
  const [translationError, setTranslationError] = useState<string | null>(null);
  const [lotteryError, setLotteryError] = useState<string | null>(null);
  const [websiteError, setWebsiteError] = useState<string | null>(null);
  const [linkError, setLinkError] = useState<string | null>(null);
  const [obfuscationError, setObfuscationError] = useState<string | null>(null);
  const [keyFetchingError, setKeyFetchingError] = useState<string | null>(null);
  const [obfuscatedLinkError, setObfuscatedLinkError] = useState<string | null>(null);
  const [loreError, setLoreError] = useState<string | null>(null);

  const [isCopied, setIsCopied] = useState<boolean>(false);
  const [isTranslatedCopied, setIsTranslatedCopied] = useState<boolean>(false);
  const [isLotteryCopied, setIsLotteryCopied] = useState<boolean>(false);
  const [isWebsiteCopied, setIsWebsiteCopied] = useState<boolean>(false);
  const [isLinkCopied, setIsLinkCopied] = useState<boolean>(false);
  const [isObfuscatedCopied, setIsObfuscatedCopied] = useState<boolean>(false);
  const [isObfuscatedLinkCopied, setIsObfuscatedLinkCopied] = useState<boolean>(false);
  const [isLoreCopied, setIsLoreCopied] = useState<boolean>(false);
  
  const [activeStyle, setActiveStyle] = useState<Style | null>(null);
  const [activeWebsiteTab, setActiveWebsiteTab] = useState<WebsiteTab>('preview');
  const [transmissionComplete, setTransmissionComplete] = useState<boolean>(false);


  const handleCorrection = useCallback(async () => {
    if (!originalText.trim()) return;
    
    setIsLoading(true);
    setError(null);
    setCorrectedText('');
    setTranslatedText('');
    setLotteryText('');
    setWebsiteHtml('');
    setGeneratedLink('');
    setObfuscatedText('');
    setCreditApiKey('');
    setKeyFetchingError(null);
    setObfuscatedLink('');
    setObfuscatedLinkError(null);
    setTransmissionComplete(false);
    setTransmissionLore('');
    setLoreError(null);
    setActiveStyle(null);
    setIsCopied(false);

    try {
      const result = await correctText(originalText);
      setCorrectedText(result);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [originalText]);

  const handleTranslate = useCallback(async (style: Style) => {
    if (!correctedText) return;

    setIsTranslating(true);
    setTranslationError(null);
    setTranslatedText('');
    setActiveStyle(style);
    setIsTranslatedCopied(false);

    try {
        const result = await translateText(correctedText, style);
        setTranslatedText(result);
    } catch (e) {
        setTranslationError(e instanceof Error ? e.message : 'An unknown error occurred.');
    } finally {
        setIsTranslating(false);
    }
  }, [correctedText]);
  
  const handleLottery = useCallback(async () => {
    if (!correctedText) return;

    setIsLotteryLoading(true);
    setLotteryError(null);
    setLotteryText('');
    setWebsiteHtml('');
    setGeneratedLink('');
    setObfuscatedText('');
    setCreditApiKey('');
    setKeyFetchingError(null);
    setObfuscatedLink('');
    setObfuscatedLinkError(null);
    setTransmissionComplete(false);
    setTransmissionLore('');
    setLoreError(null);
    setIsLotteryCopied(false);

    try {
        const result = await getLotteryResult(correctedText);
        setLotteryText(result);
    } catch (e) {
        setLotteryError(e instanceof Error ? e.message : 'An unknown error occurred.');
    } finally {
        setIsLotteryLoading(false);
    }
  }, [correctedText]);
  
  const handleWebsiteTeleport = useCallback(async () => {
    if (!lotteryText) return;

    setIsWebsiteLoading(true);
    setWebsiteError(null);
    setWebsiteHtml('');
    setIsWebsiteCopied(false);
    setActiveWebsiteTab('preview');

    try {
        const result = await teleportToWebsite(lotteryText);
        setWebsiteHtml(result);
    } catch (e) {
        setWebsiteError(e instanceof Error ? e.message : 'An unknown error occurred.');
    } finally {
        setIsWebsiteLoading(false);
    }
  }, [lotteryText]);

  const handleLinkGeneration = useCallback(async () => {
    if (!lotteryText) return;

    setIsLinkLoading(true);
    setLinkError(null);
    setGeneratedLink('');
    setIsLinkCopied(false);

    try {
        const result = await generateHyperlink(lotteryText);
        setGeneratedLink(result);
    } catch (e) {
        setLinkError(e instanceof Error ? e.message : 'An unknown error occurred.');
    } finally {
        setIsLinkLoading(false);
    }
  }, [lotteryText]);

  const handleObfuscation = useCallback(async () => {
    if (!lotteryText) return;

    setIsObfuscating(true);
    setObfuscationError(null);
    setObfuscatedText('');
    setIsObfuscatedCopied(false);
    setCreditApiKey('');
    setKeyFetchingError(null);
    setObfuscatedLink('');
    setObfuscatedLinkError(null);
    setTransmissionComplete(false);
    setTransmissionLore('');
    setLoreError(null);

    try {
        const result = await obfuscateText(lotteryText);
        setObfuscatedText(result);
    } catch (e) {
        setObfuscationError(e instanceof Error ? e.message : 'An unknown error occurred.');
    } finally {
        setIsObfuscating(false);
    }
  }, [lotteryText]);

  const handleRequestKey = useCallback(async () => {
    setIsFetchingKey(true);
    setKeyFetchingError(null);
    setCreditApiKey('');
    setObfuscatedLink('');
    setObfuscatedLinkError(null);
    setTransmissionComplete(false);

    try {
        const key = await generateTransmissionKey();
        setCreditApiKey(key);
    } catch (e) {
        setKeyFetchingError(e instanceof Error ? e.message : 'An unknown error occurred.');
    } finally {
        setIsFetchingKey(false);
    }
  }, []);
    
  const handleObfuscatedLinkGeneration = useCallback(async () => {
    if (!obfuscatedText || !creditApiKey) return;

    setIsObfuscatedLinkLoading(true);
    setObfuscatedLinkError(null);
    setObfuscatedLink('');
    setIsObfuscatedLinkCopied(false);
    setTransmissionComplete(false);

    try {
        const result = await generateHyperlink(obfuscatedText, creditApiKey);
        setObfuscatedLink(result);
    } catch (e) {
        setObfuscatedLinkError(e instanceof Error ? e.message : 'An unknown error occurred.');
    } finally {
        setIsObfuscatedLinkLoading(false);
    }
  }, [obfuscatedText, creditApiKey]);

  const handleManualKeySubmit = useCallback(() => {
    if (manualKeyInput.trim()) {
        setCreditApiKey(manualKeyInput.trim());
        setKeyFetchingError(null);
        setManualKeyInput('');
    }
  }, [manualKeyInput]);

  const handleCompleteTransmission = useCallback(() => {
    setIsCompletingTransmission(true);
    setTimeout(() => {
        setIsCompletingTransmission(false);
        setTransmissionComplete(true);
    }, 1500); // Simulate network delay
  }, []);
  
  const handleGenerateLore = useCallback(async () => {
    if (!originalText) return;

    setIsLoreLoading(true);
    setLoreError(null);
    setTransmissionLore('');
    setIsLoreCopied(false);

    try {
        const result = await generateTransmissionLore(originalText);
        setTransmissionLore(result);
    } catch (e) {
        setLoreError(e instanceof Error ? e.message : 'An unknown error occurred.');
    } finally {
        setIsLoreLoading(false);
    }
  }, [originalText]);


  const handleCopy = useCallback((textToCopy: string, setCopiedState: React.Dispatch<React.SetStateAction<boolean>>) => {
    if (textToCopy) {
      navigator.clipboard.writeText(textToCopy);
      setCopiedState(true);
      setTimeout(() => setCopiedState(false), 2000);
    }
  }, []);

  const handleClear = () => {
    setOriginalText('');
    setCorrectedText('');
    setTranslatedText('');
    setLotteryText('');
    setWebsiteHtml('');
    setGeneratedLink('');
    setObfuscatedText('');
    setCreditApiKey('');
    setObfuscatedLink('');
    setTransmissionLore('');
    setError(null);
    setTranslationError(null);
    setLotteryError(null);
    setWebsiteError(null);
    setLinkError(null);
    setObfuscationError(null);
    setKeyFetchingError(null);
    setObfuscatedLinkError(null);
    setLoreError(null);
    setIsCopied(false);
    setIsTranslatedCopied(false);
    setIsLotteryCopied(false);
    setIsWebsiteCopied(false);
    setIsLinkCopied(false);
    setIsObfuscatedCopied(false);
    setIsObfuscatedLinkCopied(false);
    setIsLoreCopied(false);
    setActiveStyle(null);
    setActiveWebsiteTab('preview');
    setTransmissionComplete(false);
  };

  const hasContent = originalText.trim().length > 0;

  return (
    <div className="bg-slate-900 text-white min-h-screen flex flex-col items-center justify-center p-4 font-sans antialiased">
      <main className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-2xl shadow-2xl p-6 md:p-8 w-full max-w-3xl space-y-6">
        <header className="text-center">
          <h1 className="text-3xl md:text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-teal-300">
            Gemini Grammar Corrector
          </h1>
          <p className="text-slate-400 mt-2">
            Polish your writing and teleport its style with the power of AI.
          </p>
        </header>

        <div className="relative">
          <textarea
            value={originalText}
            onChange={(e) => setOriginalText(e.target.value)}
            placeholder="Enter your text here... for example: 'onctient corse spirit teleport port fowart exe generetrror!'"
            className="w-full h-40 bg-slate-900/80 border border-slate-700 rounded-lg p-4 focus:ring-2 focus:ring-blue-500 focus:outline-none transition-shadow resize-none"
            disabled={isLoading}
          />
          {hasContent && !isLoading && (
             <button
                onClick={handleClear}
                className="absolute top-3 right-3 text-slate-500 hover:text-white transition-colors"
                aria-label="Clear input"
            >
                <Icon name="clear" className="w-5 h-5" />
            </button>
          )}
        </div>
        
        <div className="flex justify-center">
            <button
                onClick={handleCorrection}
                disabled={!hasContent || isLoading}
                className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-bold py-3 px-8 rounded-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-2 shadow-lg disabled:shadow-none"
            >
                {isLoading ? (
                    <>
                        <Spinner />
                        <span>Correcting...</span>
                    </>
                ) : (
                    <>
                        <Icon name="sparkles" className="w-5 h-5" />
                        <span>Correct Grammar</span>
                    </>
                )}
            </button>
        </div>

        {(correctedText || isLoading || error) && (
            <div className="space-y-2">
                <h2 className="text-lg font-semibold text-slate-300">Corrected Text</h2>
                <div className="relative bg-slate-900/80 border border-slate-700 rounded-lg p-4 min-h-[160px] text-slate-200 whitespace-pre-wrap">
                    {isLoading && !correctedText && (
                        <div className="absolute inset-0 flex items-center justify-center">
                            <div className="flex flex-col items-center gap-2">
                                <Spinner />
                                <span className="text-slate-400">AI is thinking...</span>
                            </div>
                        </div>
                    )}
                    {error && <div className="text-red-400"><p className="font-semibold">Error:</p><p>{error}</p></div>}
                    {correctedText && !error && (
                        <>
                            <p>{correctedText}</p>
                            <button
                                onClick={() => handleCopy(correctedText, setIsCopied)}
                                className="absolute top-3 right-3 bg-slate-700 hover:bg-slate-600 text-slate-300 p-2 rounded-md transition-colors"
                                aria-label="Copy corrected text"
                            >
                                {isCopied ? <Icon name="clipboardCheck" className="w-5 h-5 text-green-400" /> : <Icon name="copy" className="w-5 h-5" />}
                            </button>
                        </>
                    )}
                </div>
            </div>
        )}

        {correctedText && !error && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
                {/* Style Translator */}
                <div className="space-y-4">
                    <h2 className="text-lg font-semibold text-slate-300">Translate Style</h2>
                    <div className="grid grid-cols-2 gap-3">
                        {STYLES.map(({ name, icon }) => (
                            <button
                                key={name}
                                onClick={() => handleTranslate(name)}
                                disabled={isTranslating}
                                className={`flex items-center justify-center gap-2 p-3 rounded-lg border transition-all duration-200 ${
                                    activeStyle === name
                                        ? 'bg-teal-500/20 border-teal-400 text-teal-300'
                                        : 'bg-slate-700/50 border-slate-600 hover:bg-slate-700 hover:border-slate-500'
                                } disabled:opacity-50 disabled:cursor-not-allowed`}
                            >
                                <Icon name={icon} className="w-5 h-5" />
                                <span>{name}</span>
                            </button>
                        ))}
                    </div>
                </div>

                {/* Data Lottery */}
                <div className="space-y-4">
                    <h2 className="text-lg font-semibold text-slate-300">Try Your Luck</h2>
                    <button
                        onClick={handleLottery}
                        disabled={isLotteryLoading}
                        className="w-full flex items-center justify-center gap-2 p-3 rounded-lg border transition-all duration-200 bg-purple-600/20 border-purple-500 hover:bg-purple-600/40 hover:border-purple-400 text-purple-300 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {isLotteryLoading ? (
                            <>
                                <Spinner />
                                <span>Teleporting...</span>
                            </>
                        ) : (
                            <>
                                <Icon name="dice" className="w-5 h-5" />
                                <span>Data Lottery Teleporter</span>
                            </>
                        )}
                    </button>
                </div>
            </div>
        )}

        {(translatedText || isTranslating || translationError) && (
            <div className="space-y-2">
                <h2 className="text-lg font-semibold text-slate-300">Translated Text</h2>
                <div className="relative bg-slate-900/80 border border-slate-700 rounded-lg p-4 min-h-[160px] text-slate-200 whitespace-pre-wrap">
                    {isTranslating && (
                        <div className="absolute inset-0 flex items-center justify-center">
                            <div className="flex flex-col items-center gap-2">
                                <Spinner />
                                <span className="text-slate-400">Teleporting style...</span>
                            </div>
                        </div>
                    )}
                    {translationError && <div className="text-red-400"><p className="font-semibold">Error:</p><p>{translationError}</p></div>}
                    {translatedText && !translationError && (
                        <>
                            <p>{translatedText}</p>
                            <button
                                onClick={() => handleCopy(translatedText, setIsTranslatedCopied)}
                                className="absolute top-3 right-3 bg-slate-700 hover:bg-slate-600 text-slate-300 p-2 rounded-md transition-colors"
                                aria-label="Copy translated text"
                            >
                                {isTranslatedCopied ? <Icon name="clipboardCheck" className="w-5 h-5 text-green-400" /> : <Icon name="copy" className="w-5 h-5" />}
                            </button>
                        </>
                    )}
                </div>
            </div>
        )}

        {(lotteryText || isLotteryLoading || lotteryError) && (
             <div className="space-y-2">
                <h2 className="text-lg font-semibold text-slate-300">Lottery Result!</h2>
                <div className="relative bg-slate-900/80 border border-slate-700 rounded-lg p-4 min-h-[160px] text-slate-200 whitespace-pre-wrap">
                    {isLotteryLoading && (
                        <div className="absolute inset-0 flex items-center justify-center">
                            <div className="flex flex-col items-center gap-2">
                                <Spinner />
                                <span className="text-slate-400">Rolling the dice...</span>
                            </div>
                        </div>
                    )}
                    {lotteryError && <div className="text-red-400"><p className="font-semibold">Error:</p><p>{lotteryError}</p></div>}
                    {lotteryText && !lotteryError && (
                        <>
                            <p>{lotteryText}</p>
                            <button
                                onClick={() => handleCopy(lotteryText, setIsLotteryCopied)}
                                className="absolute top-3 right-3 bg-slate-700 hover:bg-slate-600 text-slate-300 p-2 rounded-md transition-colors"
                                aria-label="Copy lottery text"
                            >
                                {isLotteryCopied ? <Icon name="clipboardCheck" className="w-5 h-5 text-green-400" /> : <Icon name="copy" className="w-5 h-5" />}
                            </button>
                        </>
                    )}
                </div>
            </div>
        )}
        
        {lotteryText && !lotteryError && (
            <div className="space-y-4 pt-4">
                <h2 className="text-lg font-semibold text-slate-300">Ancient Teleporter</h2>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <button
                        onClick={handleWebsiteTeleport}
                        disabled={isWebsiteLoading}
                        className="w-full flex items-center justify-center gap-2 p-3 rounded-lg border transition-all duration-200 bg-yellow-600/20 border-yellow-500 hover:bg-yellow-600/40 hover:border-yellow-400 text-yellow-300 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {isWebsiteLoading ? (
                            <>
                                <Spinner />
                                <span>Teleporting...</span>
                            </>
                        ) : (
                            <>
                                <Icon name="globe" className="w-5 h-5" />
                                <span>Teleport to Website</span>
                            </>
                        )}
                    </button>
                    <button
                        onClick={handleLinkGeneration}
                        disabled={isLinkLoading}
                        className="w-full flex items-center justify-center gap-2 p-3 rounded-lg border transition-all duration-200 bg-green-600/20 border-green-500 hover:bg-green-600/40 hover:border-green-400 text-green-300 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {isLinkLoading ? (
                            <>
                                <Spinner />
                                <span>Generating...</span>
                            </>
                        ) : (
                            <>
                                <Icon name="link" className="w-5 h-5" />
                                <span>Generate Hyperlink</span>
                            </>
                        )}
                    </button>
                    <button
                        onClick={handleObfuscation}
                        disabled={isObfuscating}
                        className="w-full flex items-center justify-center gap-2 p-3 rounded-lg border transition-all duration-200 bg-red-600/20 border-red-500 hover:bg-red-600/40 hover:border-red-400 text-red-300 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {isObfuscating ? (
                            <>
                                <Spinner />
                                <span>Obfuscating...</span>
                            </>
                        ) : (
                            <>
                                <Icon name="shield-slash" className="w-5 h-5" />
                                <span>Obfuscate Text</span>
                            </>
                        )}
                    </button>
                </div>
            </div>
        )}
        
        {(websiteHtml || isWebsiteLoading || websiteError) && (
            <div className="space-y-2">
                 <div className="flex justify-between items-center">
                    <h2 className="text-lg font-semibold text-slate-300">Website Teleporter Result</h2>
                    {websiteHtml && !websiteError && (
                        <div className="flex items-center gap-2">
                             <div className="flex rounded-md bg-slate-700/50 p-0.5 border border-slate-700">
                                <button
                                    onClick={() => setActiveWebsiteTab('preview')}
                                    className={`flex items-center gap-1.5 px-3 py-1 text-sm rounded-md transition-colors ${activeWebsiteTab === 'preview' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:bg-slate-600/50'}`}
                                >
                                    <Icon name="eye" className="w-4 h-4" />
                                    Preview
                                </button>
                                <button
                                    onClick={() => setActiveWebsiteTab('code')}
                                    className={`flex items-center gap-1.5 px-3 py-1 text-sm rounded-md transition-colors ${activeWebsiteTab === 'code' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:bg-slate-600/50'}`}
                                >
                                    <Icon name="codeBrackets" className="w-4 h-4" />
                                    Code
                                </button>
                            </div>
                            <button
                                onClick={() => handleCopy(websiteHtml, setIsWebsiteCopied)}
                                className="bg-slate-700 hover:bg-slate-600 text-slate-300 p-2 rounded-md transition-colors"
                                aria-label="Copy website code"
                            >
                                {isWebsiteCopied ? <Icon name="clipboardCheck" className="w-5 h-5 text-green-400" /> : <Icon name="copy" className="w-5 h-5" />}
                            </button>
                        </div>
                    )}
                </div>
                 <div className="relative bg-slate-900/80 border border-slate-700 rounded-lg min-h-[400px] text-slate-200 overflow-hidden">
                    {isWebsiteLoading && (
                        <div className="absolute inset-0 flex items-center justify-center">
                            <div className="flex flex-col items-center gap-2">
                                <Spinner />
                                <span className="text-slate-400">Generating website...</span>
                            </div>
                        </div>
                    )}
                    {websiteError && <div className="p-4 text-red-400"><p className="font-semibold">Error:</p><p>{websiteError}</p></div>}
                    {websiteHtml && !websiteError && (
                        <>
                           {activeWebsiteTab === 'preview' ? (
                                <iframe
                                    srcDoc={websiteHtml}
                                    title="Generated Website Preview"
                                    className="w-full h-[400px] border-0 bg-white"
                                    sandbox="allow-scripts allow-same-origin"
                                />
                            ) : (
                                <div className="p-4 h-[400px] overflow-auto">
                                    <pre className="whitespace-pre-wrap">
                                        <code>{websiteHtml}</code>
                                    </pre>
                                </div>
                            )}
                        </>
                    )}
                </div>
            </div>
        )}

        {(generatedLink || isLinkLoading || linkError) && (
            <div className="space-y-2">
                <h2 className="text-lg font-semibold text-slate-300">Generated Hyperlink</h2>
                <div className="relative bg-slate-900/80 border border-slate-700 rounded-lg p-4 min-h-[80px] text-slate-200 flex items-center">
                    {isLinkLoading && (
                        <div className="absolute inset-0 flex items-center justify-center">
                            <div className="flex flex-col items-center gap-2">
                                <Spinner />
                                <span className="text-slate-400">Generating link...</span>
                            </div>
                        </div>
                    )}
                    {linkError && <div className="text-red-400"><p className="font-semibold">Error:</p><p>{linkError}</p></div>}
                    {generatedLink && !linkError && (
                        <>
                            <a href={generatedLink} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-300 hover:underline break-all">
                                {generatedLink}
                            </a>
                            <button
                                onClick={() => handleCopy(generatedLink, setIsLinkCopied)}
                                className="absolute top-3 right-3 bg-slate-700 hover:bg-slate-600 text-slate-300 p-2 rounded-md transition-colors"
                                aria-label="Copy generated link"
                            >
                                {isLinkCopied ? <Icon name="clipboardCheck" className="w-5 h-5 text-green-400" /> : <Icon name="copy" className="w-5 h-5" />}
                            </button>
                        </>
                    )}
                </div>
            </div>
        )}
        
        {(obfuscatedText || isObfuscating || obfuscationError) && !transmissionComplete && (
            <div className="space-y-2">
                <h2 className="text-lg font-semibold text-slate-300">Obfuscated Transmission</h2>
                <div className="bg-slate-900/80 border border-slate-700 rounded-lg">
                    <div className="relative p-4 min-h-[160px] text-slate-200 whitespace-pre-wrap">
                        {isObfuscating && (
                            <div className="absolute inset-0 flex items-center justify-center">
                                <div className="flex flex-col items-center gap-2">
                                    <Spinner />
                                    <span className="text-slate-400">Engaging obfuscation matrix...</span>
                                </div>
                            </div>
                        )}
                        {obfuscationError && <div className="text-red-400"><p className="font-semibold">Error:</p><p>{obfuscationError}</p></div>}
                        {obfuscatedText && !obfuscationError && (
                            <>
                                <p className="font-mono break-all">{obfuscatedText}</p>
                                <button
                                    onClick={() => handleCopy(obfuscatedText, setIsObfuscatedCopied)}
                                    className="absolute top-3 right-3 bg-slate-700 hover:bg-slate-600 text-slate-300 p-2 rounded-md transition-colors"
                                    aria-label="Copy obfuscated text"
                                >
                                    {isObfuscatedCopied ? <Icon name="clipboardCheck" className="w-5 h-5 text-green-400" /> : <Icon name="copy" className="w-5 h-5" />}
                                </button>
                            </>
                        )}
                    </div>
                     {obfuscatedText && !obfuscationError && (
                        <div className="border-t border-slate-700 p-3 bg-slate-800/40 rounded-b-lg space-y-3">
                            {!creditApiKey && !isFetchingKey && !keyFetchingError && (
                                <button
                                    onClick={handleRequestKey}
                                    className="w-full flex items-center justify-center gap-2 p-3 rounded-lg border transition-all duration-200 bg-cyan-600/20 border-cyan-500 hover:bg-cyan-600/40 hover:border-cyan-400 text-cyan-300 disabled:opacity-50 disabled:cursor-not-allowed"
                                >
                                    <Icon name="key" className="w-5 h-5" />
                                    <span>Request Transmission Key</span>
                                </button>
                            )}

                            {isFetchingKey && (
                                <div className="flex items-center justify-center gap-2 text-cyan-400 p-3">
                                    <Spinner />
                                    <span>Generating Transmission Key...</span>
                                </div>
                            )}
                            
                            {keyFetchingError && (
                                <div className="space-y-3 p-1 text-center">
                                    <div className="text-red-400">
                                        <p className="font-semibold">Key Generation Failed</p>
                                        <p className="text-sm">{keyFetchingError}</p>
                                    </div>
                                    <p className="text-slate-400 text-sm pt-2">You can manually enter a key below:</p>
                                    <div className="flex gap-2">
                                        <input
                                            type="text"
                                            value={manualKeyInput}
                                            onChange={(e) => setManualKeyInput(e.target.value)}
                                            placeholder="Enter key manually..."
                                            className="flex-grow w-full bg-slate-900/80 border border-slate-600 rounded-md p-2 text-sm focus:ring-1 focus:ring-cyan-500 focus:outline-none"
                                            aria-label="Manual key input"
                                        />
                                        <button
                                            onClick={handleManualKeySubmit}
                                            disabled={!manualKeyInput.trim()}
                                            className="flex items-center justify-center gap-2 px-3 rounded-md border transition-all duration-200 bg-cyan-600/20 border-cyan-500 hover:bg-cyan-600/40 hover:border-cyan-400 text-cyan-300 disabled:opacity-50 disabled:cursor-not-allowed"
                                            aria-label="Use manual key"
                                        >
                                            <Icon name="keyboard" className="w-5 h-5" />
                                            <span>Use Key</span>
                                        </button>
                                    </div>
                                </div>
                            )}

                            {creditApiKey && !keyFetchingError && (
                                <div className="space-y-3">
                                    <div className="bg-slate-900/50 border border-slate-600 rounded-lg p-3 text-center">
                                        <p className="text-sm text-slate-400">Transmission Key Acquired:</p>
                                        <p className="font-mono text-green-400 break-all">{creditApiKey}</p>
                                    </div>
                                    <button
                                        onClick={handleObfuscatedLinkGeneration}
                                        disabled={isObfuscatedLinkLoading}
                                        className="w-full flex items-center justify-center gap-2 p-3 rounded-lg border transition-all duration-200 bg-teal-600/20 border-teal-500 hover:bg-teal-600/40 hover:border-teal-400 text-teal-300 disabled:opacity-50 disabled:cursor-not-allowed"
                                    >
                                        {isObfuscatedLinkLoading ? (
                                            <>
                                                <Spinner />
                                                <span>Encrypting Link...</span>
                                            </>
                                        ) : (
                                            <>
                                                <Icon name="lock" className="w-5 h-5" />
                                                <span>Generate Encrypted Link</span>
                                            </>
                                        )}
                                    </button>
                                </div>
                            )}
                        </div>
                    )}
                </div>
            </div>
        )}

        {(obfuscatedLink || isObfuscatedLinkLoading || obfuscatedLinkError) && !transmissionComplete && (
            <div className="space-y-2">
                <h2 className="text-lg font-semibold text-slate-300">Encrypted Link</h2>
                <div className="relative bg-slate-900/80 border border-slate-700 rounded-lg p-4 min-h-[80px] text-slate-200 flex items-center">
                    {isObfuscatedLinkLoading && (
                        <div className="absolute inset-0 flex items-center justify-center">
                            <div className="flex flex-col items-center gap-2">
                                <Spinner />
                                <span className="text-slate-400">Encrypting transmission...</span>
                            </div>
                        </div>
                    )}
                    {obfuscatedLinkError && <div className="text-red-400"><p className="font-semibold">Error:</p><p>{obfuscatedLinkError}</p></div>}
                    {obfuscatedLink && !obfuscatedLinkError && (
                        <>
                            <a href={obfuscatedLink} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-300 hover:underline break-all">
                                {obfuscatedLink}
                            </a>
                            <button
                                onClick={() => handleCopy(obfuscatedLink, setIsObfuscatedLinkCopied)}
                                className="absolute top-3 right-3 bg-slate-700 hover:bg-slate-600 text-slate-300 p-2 rounded-md transition-colors"
                                aria-label="Copy encrypted link"
                            >
                                {isObfuscatedLinkCopied ? <Icon name="clipboardCheck" className="w-5 h-5 text-green-400" /> : <Icon name="copy" className="w-5 h-5" />}
                            </button>
                        </>
                    )}
                </div>
            </div>
        )}
        
        {obfuscatedLink && !obfuscatedLinkError && !transmissionComplete && (
            <div className="flex justify-center pt-4">
                <button
                    onClick={handleCompleteTransmission}
                    disabled={isCompletingTransmission}
                    className="w-full sm:w-auto bg-green-600 hover:bg-green-700 disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-bold py-3 px-8 rounded-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-2 shadow-lg disabled:shadow-none"
                >
                    {isCompletingTransmission ? (
                        <>
                            <Spinner />
                            <span>Transmitting...</span>
                        </>
                    ) : (
                        <>
                            <Icon name="send" className="w-5 h-5" />
                            <span>Complete Transmission</span>
                        </>
                    )}
                </button>
            </div>
        )}

        {transmissionComplete && (
            <div className="space-y-4">
                <div className="bg-slate-900/80 border border-slate-700 rounded-lg p-6 text-center flex flex-col items-center gap-4">
                    <Icon name="check-circle" className="w-16 h-16 text-green-400" />
                    <h3 className="text-2xl font-bold text-green-300">Transmission Complete!</h3>
                    <p className="text-slate-400">Your encrypted message has traversed the digital cosmos.</p>
                     {(!transmissionLore && !isLoreLoading) && (
                         <button
                            onClick={handleGenerateLore}
                            className="w-full sm:w-auto mt-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-6 rounded-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-2 shadow-lg"
                        >
                            <Icon name={loreError ? 'refresh' : 'scroll'} className="w-5 h-5" />
                            <span>{loreError ? 'Try Again' : 'Generate Transmission Lore'}</span>
                        </button>
                    )}
                </div>
            </div>
        )}
        
        {(transmissionLore || isLoreLoading || loreError) && (
             <div className="space-y-2">
                <h2 className="text-lg font-semibold text-slate-300">Cosmic Log Entry</h2>
                <div className="relative bg-slate-900/80 border border-slate-700 rounded-lg p-4 min-h-[160px] text-slate-200 whitespace-pre-wrap">
                    {isLoreLoading && (
                        <div className="absolute inset-0 flex items-center justify-center">
                            <div className="flex flex-col items-center gap-2">
                                <Spinner />
                                <span className="text-slate-400">Retrieving cosmic logs...</span>
                            </div>
                        </div>
                    )}
                    {loreError && <div className="text-red-400"><p className="font-semibold">Error:</p><p>{loreError}</p></div>}
                    {transmissionLore && !loreError && (
                        <>
                            <p>{transmissionLore}</p>
                            <button
                                onClick={() => handleCopy(transmissionLore, setIsLoreCopied)}
                                className="absolute top-3 right-3 bg-slate-700 hover:bg-slate-600 text-slate-300 p-2 rounded-md transition-colors"
                                aria-label="Copy transmission lore"
                            >
                                {isLoreCopied ? <Icon name="clipboardCheck" className="w-5 h-5 text-green-400" /> : <Icon name="copy" className="w-5 h-5" />}
                            </button>
                        </>
                    )}
                </div>
            </div>
        )}

      </main>
      <footer className="text-center mt-8 text-slate-500 text-sm">
        <p>Powered by Google Gemini</p>
      </footer>
    </div>
  );
};

export default App;