import { GoogleGenAI } from "@google/genai";

// Assume process.env.API_KEY is securely available in the environment
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // In a real app, you might use a toast notification or a different UI to show this error.
  // For this context, throwing an error is sufficient to indicate a critical configuration issue.
  console.error("API_KEY is not defined in environment variables. Please set it to use the application.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY as string });

async function callGemini(prompt: string, errorMessage: string): Promise<string> {
    if (!API_KEY) {
        throw new Error("API Key is not configured. Cannot contact the AI service.");
    }

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        // Handle cases where the model might wrap the code in markdown
        const text = response.text.trim();
        if (text.startsWith('```html')) {
            return text.replace(/^```html\n|```$/g, '');
        }
        return text;
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error(errorMessage);
    }
}


export async function correctText(text: string): Promise<string> {
  if (!text.trim()) {
    return "";
  }
  
  const prompt = `You are an expert proofreader. Correct all spelling mistakes and grammatical errors in the following text. Preserve the original intent and tone. Return only the corrected text, without any explanations, conversational filler, or introductory phrases like "Here is the corrected text:".

Original text:
---
${text}
---

Corrected text:`;

  return callGemini(prompt, "Failed to get a correction from the AI. Please check your API key and network connection.");
}

const getTranslationPrompt = (text: string, style: string): string => {
    switch (style) {
        case 'Formal':
            return `You are an expert editor. Rewrite the following text in a formal, professional, and sophisticated tone. Ensure the core meaning is preserved.
---
${text}
---
Formal text:`;
        case 'Casual':
            return `You are a creative writer. Rewrite the following text in a casual, friendly, and conversational tone, as if speaking to a friend.
---
${text}
---
Casual text:`;
        case 'Code Comments':
            return `You are a software engineer. Convert the following text into C++ style code comments. Each line should start with "// ".
---
${text}
---
Code comments:`;
        case 'Pirate':
            return `You are a swashbuckling pirate. Rewrite the following text in a thick pirate accent. Be creative and use plenty of pirate slang like "Ahoy!", "Matey", and "Shiver me timbers!".
---
${text}
---
Pirate speech:`;
        default:
            return text;
    }
}

export async function translateText(text: string, style: string): Promise<string> {
    if (!text.trim()) {
        return "";
    }
    const prompt = getTranslationPrompt(text, style);
    return callGemini(prompt, `Failed to translate text to ${style} style. The AI might be on a treasure hunt.`);
}

export async function getLotteryResult(text: string): Promise<string> {
    if (!text.trim()) {
        return "";
    }

    const prompt = `You are a "Data Lottery Teleporter". Your job is to take the given text and transform it into a completely random and unexpected format. Be creative and surprising. Possible formats include, but are not limited to: a haiku, a corporate memo, a recipe, a news headline from the future, a rhyming couplet, a movie trailer script, a technical specification, or a philosophical quote. Do not explain your choice, just provide the transformed text.

Original text:
---
${text}
---

Teleported text:`;

    return callGemini(prompt, "The data teleporter seems to be experiencing technical difficulties. Please try again.");
}

export async function teleportToWebsite(text: string): Promise<string> {
    if (!text.trim()) {
        return "";
    }

    const prompt = `You are an expert web developer with a flair for creative design. Convert the following text into a complete, single-file HTML document. Use inline CSS within a <style> tag in the <head> to create a visually appealing design that reflects the theme and tone of the content. The entire response must be ONLY the raw HTML code, starting with <!DOCTYPE html> and ending with </html>. Do not wrap it in markdown or provide any explanation.

Original text:
---
${text}
---

HTML code:`;

    return callGemini(prompt, "The website teleporter malfunctioned. The dimensional fabric is currently being repaired.");
}

export async function generateTransmissionKey(): Promise<string> {
    const prompt = `You are a secure key generator. Create a single, random, 32-character alphanumeric transmission key. The key should be a mix of uppercase letters, lowercase letters, and numbers. Return ONLY the 32-character key and absolutely nothing else. Do not add any explanation, labels, or formatting.`;

    const key = await callGemini(prompt, "Failed to generate transmission key. The AI key forge might be offline.");
    // Basic validation to ensure the key looks like a key and not a sentence.
    if (key.length < 20 || key.length > 40 || key.includes(' ')) {
        console.error("Generated key is in an unexpected format:", key);
        throw new Error("AI generated an invalid key format. Please try again.");
    }
    return key;
}

export async function generateHyperlink(text: string, apiKey?: string): Promise<string> {
    if (!text.trim()) {
        return "";
    }

    let prompt: string;
    let errorMessage: string;

    if (apiKey) {
        prompt = `You are a "Meteor Protocol" encryption agent. Your task is to generate a secure HTTPS link for a private data transmission. The link must look like it's from a service called "Meteor" and contain the obfuscated text as an encrypted payload in a query parameter or path. Use the transmission key for authentication, perhaps as another parameter or a header hint in the URL structure. Return ONLY the full HTTPS URL and nothing else.

Obfuscated Text:
---
${text}
---

Transmission Key: ${apiKey}

Encrypted Meteor Link:`;
        errorMessage = "Meteor Protocol encryption failed. A solar flare may have interfered with the signal.";
    } else {
        prompt = `You are a creative HTTPS link generator. Based on the following text, invent a plausible and thematic HTTPS URL. The URL does not need to be real, but it should look authentic, starting with "https://". Return ONLY the full HTTPS URL and nothing else. Do not add any explanation or surrounding text.

Original text:
---
${text}
---

Generated Link:`;
        errorMessage = "The hyperlink generator is lost in hyperspace. Please try again.";
    }

    return callGemini(prompt, errorMessage);
}

export async function obfuscateText(text: string): Promise<string> {
    if (!text.trim()) {
        return "";
    }

    const prompt = `You are a "Data Obfuscation Protocol". Your task is to take the provided text and rewrite it in a heavily obscured, creative, and difficult-to-read format. Use a mix of techniques like leetspeak, symbols, base64 encoding snippets, reversing words, or creating a simple substitution cipher. The goal is to make the text unreadable at a glance. Do not explain the method used. Return only the obfuscated text.

Original text:
---
${text}
---

Obfuscated Transmission:`;

    return callGemini(prompt, "The obfuscation matrix is unstable. Signal lost.");
}

export async function generateTransmissionLore(text: string): Promise<string> {
    if (!text.trim()) {
        return "";
    }
    
    const prompt = `You are a "Cosmic Chronicler," a storyteller who records the epic journeys of data packets through the digital universe. Based on the original text provided below, write a short, imaginative, and exciting "lore" entry about this specific transmission. Describe its journey through digital nebulae, past firewalls of legend, and how it finally reached its destination. Return only the story.

Original text snippet for inspiration:
---
${text}
---

Cosmic Log Entry:`;

  return callGemini(prompt, "Failed to retrieve the transmission lore. The cosmic archives appear to be closed.");
}